from django.contrib import admin

from .models import Product, Media

admin.site.register(Product)
admin.site.register(Media)
